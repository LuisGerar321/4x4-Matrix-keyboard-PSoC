#include "project.h"
#include "matrix_library.h"





int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    CY_ISR(Matrix_Callbacks);
    isr_MATRIX_StartEx(Matrix_Callbacks);
    Matrix_ClearInterrupt();

    LCD_Enable();
    LCD_Start();
    LCD_Position(0,0);
    LCD_ClearDisplay();
    
    UART_Enable();
    UART_Start();
    
    //MatrixCheckLoop("LCD",keypad_scan);

    for(;;)
    {
        UART_PutString("Hola mundo\n");
    }
}

CY_ISR(Matrix_Callbacks){
    
    LED_Write(!LED_Read());
    
    //Leer el boton que el usuario presiona
    //keypad_scan();
    
    //LCD_Position(0,0);
    //LCD_PutChar(key);
    
    //Leer un mensaje//
    keypad_scanLine('#', 4, keypad_scan);
    LCD_Position(0,0);
    LCD_PrintString(keyLine);
    
    isr_MATRIX_ClearPending();
    Matrix_ClearInterrupt();
}

