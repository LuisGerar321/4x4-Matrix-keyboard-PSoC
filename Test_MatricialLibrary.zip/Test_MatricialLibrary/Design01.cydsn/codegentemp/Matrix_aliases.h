/*******************************************************************************
* File Name: Matrix.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Matrix_ALIASES_H) /* Pins Matrix_ALIASES_H */
#define CY_PINS_Matrix_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Matrix_0			(Matrix__0__PC)
#define Matrix_0_INTR	((uint16)((uint16)0x0001u << Matrix__0__SHIFT))

#define Matrix_1			(Matrix__1__PC)
#define Matrix_1_INTR	((uint16)((uint16)0x0001u << Matrix__1__SHIFT))

#define Matrix_2			(Matrix__2__PC)
#define Matrix_2_INTR	((uint16)((uint16)0x0001u << Matrix__2__SHIFT))

#define Matrix_3			(Matrix__3__PC)
#define Matrix_3_INTR	((uint16)((uint16)0x0001u << Matrix__3__SHIFT))

#define Matrix_4			(Matrix__4__PC)
#define Matrix_4_INTR	((uint16)((uint16)0x0001u << Matrix__4__SHIFT))

#define Matrix_5			(Matrix__5__PC)
#define Matrix_5_INTR	((uint16)((uint16)0x0001u << Matrix__5__SHIFT))

#define Matrix_6			(Matrix__6__PC)
#define Matrix_6_INTR	((uint16)((uint16)0x0001u << Matrix__6__SHIFT))

#define Matrix_7			(Matrix__7__PC)
#define Matrix_7_INTR	((uint16)((uint16)0x0001u << Matrix__7__SHIFT))

#define Matrix_INTR_ALL	 ((uint16)(Matrix_0_INTR| Matrix_1_INTR| Matrix_2_INTR| Matrix_3_INTR| Matrix_4_INTR| Matrix_5_INTR| Matrix_6_INTR| Matrix_7_INTR))

#endif /* End Pins Matrix_ALIASES_H */


/* [] END OF FILE */
